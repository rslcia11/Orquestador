import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
    LayoutDashboard, Server, Users, Bell, Search, Filter,
    CheckCircle2, AlertTriangle, Monitor, X, History,
    Menu, ChevronRight, ArrowUpDown, Terminal as TerminalIcon,
    Settings, Radio, Calendar, Plus, ExternalLink, RefreshCw,
    Activity, HardDrive, Cpu, Globe, Target
} from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { orchestratorService } from '@/services/orchestrator.service';
import { useAdminWS } from '@/hooks/useAdminWS'; // ✅ FIX 1: import del hook
import {
    ComputerNode, ProfileItem, Alert, KPIStats,
    SystemEvent, ServiceStatus, ConnectionItem, BackupStatus
} from '@/types/orchestratorTypes';
import {
    AdminKPICard, ComputerRow, AlertItem, SkeletonKPI,
    SkeletonRow, HealthOverview, SystemEventsFeed, ServiceStatusBar,
    ConnectionRow, ProfileRow, GlobalStatusHero, MiniCapacityPanel,
    JobsQueueWidget, FilterButton, SettingsPanel
} from '@/components/OrchestratorComponents';
import {
    NodeItemDrawer, AlertModal, SessionHistoryModal, JobDrawer,
    DashKPIModal, DashFiltersDrawer, HealthDetailModal, ServiceDetailModal,
    SecurityCheckModal, SessionStartModal, CreateProfileModal, EventDetailModal,
    SystemDiagnosticModal, ResourceDetailModal, JobQueueModal
} from '@/components/OrchestratorDrawers';

// --- SUB-COMPONENT: SIDEBAR ---
const SidebarItem = ({ label, active, onClick, icon }: any) => (
    <button
        onClick={onClick}
        className={`w-full aspect-square rounded-2xl flex flex-col gap-1 items-center justify-center transition-all group relative ${
            active
                ? 'bg-[#00ff88]/10 text-[#00ff88] shadow-[0_0_15px_rgba(0,255,136,0.1)]'
                : 'text-[#444] hover:text-white hover:bg-white/5'
        }`}
    >
        {active && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-[#00ff88] rounded-r-full shadow-[0_0_10px_rgba(0,255,136,0.5)]" />
        )}
        {icon}
        <span className="text-[9px] font-black uppercase tracking-wider">{label}</span>
    </button>
);

// --- MAIN SCREEN ---
const OrchestratorTerminal: React.FC = () => {
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();

    // ─── DATA STATE ───────────────────────────────────────────────
    const [stats, setStats]               = useState<KPIStats | null>(null);
    const [nodes, setNodes]               = useState<ComputerNode[]>([]);
    const [profiles, setProfiles]         = useState<ProfileItem[]>([]);
    const [alerts, setAlerts]             = useState<Alert[]>([]);
    const [events, setEvents]             = useState<SystemEvent[]>([]);
    const [services, setServices]         = useState<ServiceStatus[]>([]);
    const [connections, setConnections]   = useState<ConnectionItem[]>([]);
    const [backupStatus, setBackupStatus] = useState<BackupStatus | undefined>(undefined);

    // ─── DRAWER / MODAL STATE ─────────────────────────────────────
    const [selectedNode, setSelectedNode]         = useState<ComputerNode | null>(null);
    const [nodeHistory, setNodeHistory]           = useState<{ time: string; cpu: number; ram: number }[]>([]);
    const [selectedAlert, setSelectedAlert]       = useState<Alert | null>(null);
    const [selectedService, setSelectedService]   = useState<ServiceStatus | null>(null);
    const [securityProfile, setSecurityProfile]   = useState<ProfileItem | null>(null);
    const [selectedEvent, setSelectedEvent]       = useState<SystemEvent | null>(null);
    const [showSessionModal, setShowSessionModal] = useState(false);
    const [showCreateProfileModal, setShowCreateProfileModal] = useState(false);

    // ─── PROFILE HISTORY STATE ────────────────────────────────────
    // ✅ FIX 2: estados movidos aquí arriba, no mezclados con lógica
    const [selectedProfileHistoryId, setSelectedProfileHistoryId]   = useState<string | null>(null);
    const [profileHistoryData, setProfileHistoryData]               = useState<SystemEvent[]>([]);

    // ─── DASHBOARD-SPECIFIC STATE ─────────────────────────────────
    const [dashFilters, setDashFilters]       = useState({ timeRange: '1h', severity: 'ALL', owner: 'ALL', cookieStatus: 'ALL' });
    const [showDashFilters, setShowDashFilters]   = useState(false);
    const [dashModal, setDashModal]           = useState<{ type: string | null; data: any }>({ type: null, data: null });
    const [showHealthDetail, setShowHealthDetail] = useState(false);
    const [showSystemDiag, setShowSystemDiag]     = useState(false);
    const [showResourceDetail, setShowResourceDetail] = useState(false);
    const [showJobQueue, setShowJobQueue]         = useState(false);

    // ─── UI STATE ─────────────────────────────────────────────────
    const [loading, setLoading]       = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [autoRefresh, setAutoRefresh] = useState(true);

    // ─── URL PERSISTENCE ──────────────────────────────────────────
    const getInitialTab = () => {
        const tab = searchParams.get('tab');
        return (
            tab === 'NODES' || tab === 'PROFILES' || tab === 'ALERTS' ||
            tab === 'CONNECTIONS' || tab === 'SETTINGS'
        ) ? tab : 'DASHBOARD';
    };

    const [activeTab, setActiveTab] = useState<
        'DASHBOARD' | 'NODES' | 'PROFILES' | 'ALERTS' | 'CONNECTIONS' | 'SETTINGS'
    >(getInitialTab() as any);

    const [searchText, setSearchText] = useState(searchParams.get('q') || '');

    const getInitialFilters = () => ({
        status:     searchParams.get('status')  || 'ALL',
        minLatency: Number(searchParams.get('minLat')) || 0,
        minMem:     Number(searchParams.get('minMem')) || 0,
    });
    const [filters, setFilters] = useState(getInitialFilters());

    // Persist tab changes to URL
    useEffect(() => {
        setSearchParams(prev => { prev.set('tab', activeTab); return prev; });
    }, [activeTab]);

    // Persist search/filter changes to URL (debounced)
    useEffect(() => {
        const t = setTimeout(() => {
            setSearchParams(prev => {
                searchText ? prev.set('q', searchText) : prev.delete('q');
                filters.status !== 'ALL' ? prev.set('status', filters.status) : prev.delete('status');
                filters.minLatency > 0 ? prev.set('minLat', filters.minLatency.toString()) : prev.delete('minLat');
                filters.minMem > 0 ? prev.set('minMem', filters.minMem.toString()) : prev.delete('minMem');
                return prev;
            });
        }, 500);
        return () => clearTimeout(t);
    }, [searchText, filters]);

    // ─── DATA FETCH ───────────────────────────────────────────────
    // ✅ FIX 3: fetchData envuelto en useCallback para ser referencia estable
    const fetchData = useCallback(async () => {
        setRefreshing(true);
        try {
            const [s, n, p, a, e, svc, c, b] = await Promise.all([
                orchestratorService.getDashboardStats(),
                orchestratorService.getNodes(),
                orchestratorService.getProfiles(),
                orchestratorService.getAlerts(),
                orchestratorService.getSystemEvents(),
                orchestratorService.getServicesStatus(),
                orchestratorService.getConnections(),
                orchestratorService.getBackups(),
                // ✅ FIX 4: getJobs() eliminado — descartado del negocio
            ]);
            setStats(s);
            setNodes(n);
            setProfiles(p);
            setAlerts(a);
            setEvents(e);
            setServices(svc);
            setConnections(c);
            setBackupStatus(b);
        } catch (err) {
            console.error('[OrchestratorTerminal] fetchData failed:', err);
        } finally {
            setRefreshing(false);
            setLoading(false);
        }
    }, []); // sin dependencias — no cambia entre renders

    // Fetch inicial
    useEffect(() => { fetchData(); }, [fetchData]);

    // ─── WEBSOCKET REAL-TIME ──────────────────────────────────────
    // ✅ FIX 5: useAdminWS correctamente conectado con fetchData estable
    useAdminWS(
        useCallback((event) => {
            if (event.type === 'session_created' || event.type === 'session_active') {
                setEvents(prev => [{
                    id:        `ws-${Date.now()}`,
                    type:      'SUCCESS' as const,
                    message:   event.message ?? `Sesión creada — ${event.profile}`,
                    source:    event.agent_name ?? 'Agent',
                    timestamp: new Date().toLocaleTimeString(),
                }, ...prev.slice(0, 18)]);
                if (autoRefresh) fetchData();
            }

            if (event.type === 'session_closed') {
                setEvents(prev => [{
                    id:        `ws-${Date.now()}`,
                    type:      'INFO' as const,
                    message:   `Sesión cerrada — ${event.duration_seconds ?? 0}s`,
                    source:    event.agent_name ?? 'Agent',
                    timestamp: new Date().toLocaleTimeString(),
                }, ...prev.slice(0, 18)]);
                if (autoRefresh) fetchData();
            }

            if (event.type === 'agent_checkin') {
                setNodes(prev => prev.map(n =>
                    n.id.toString() === event.computer_id?.toString()
                        ? { ...n, status: 'ONLINE' as const }
                        : n
                ));
            }
        }, [autoRefresh, fetchData]),
        autoRefresh
    );

    // ─── HANDLERS ────────────────────────────────────────────────

    const handleNodeClick = async (node: ComputerNode) => {
        setSelectedNode(node);
        const history = await orchestratorService.getNodeHistory(node.id);
        setNodeHistory(history);
    };

    // ✅ FIX 6: handleStartSessions conectado al SessionStartModal
    const handleStartSessions = async (selectedIds: string[]) => {
        const defaultComputer = nodes.find(n => n.status === 'ONLINE');
        if (!defaultComputer) {
            alert('No hay computadoras online disponibles');
            return;
        }

        const results = await Promise.allSettled(
            selectedIds.map(profileId => {
                const profile = profiles.find(p => p.id === profileId);
                if (!profile) return Promise.reject('Profile not found');
                return orchestratorService.openBrowser({
                    profileAdsId: profile.adsId,
                    computerId:   parseInt(defaultComputer.id),
                    targetUrl:    'https://www.google.com',
                    agentName:    'admin-panel',
                });
            })
        );

        const ok     = results.filter(r => r.status === 'fulfilled').length;
        const failed = results.filter(r => r.status === 'rejected').length;
        alert(`Iniciadas: ${ok} sesiones. Fallidas: ${failed}`);
        setShowSessionModal(false);
        fetchData();
    };

    // ✅ FIX 7: handleVerifyProfile conectado al SecurityCheckModal
    const handleVerifyProfile = async (profileId: string) => {
        try {
            const result = await orchestratorService.verifyProfileSecurity(profileId);
            setProfiles(prev => prev.map(p =>
                p.id === profileId
                    ? {
                        ...p,
                        browserScore:     result.browser_score,
                        fingerprintScore: result.fingerprint_score,
                        cookieStatus:     result.cookie_status,
                    }
                    : p
            ));
            alert(`Verificado ✓  Browser: ${result.browser_score}%  |  Cookies: ${result.cookie_status}`);
            setSecurityProfile(null);
        } catch {
            alert('Error al verificar perfil. Comprueba la conexión con AdsPower.');
        }
    };

    // ✅ FIX 8: handleViewProfileHistory conectado al SessionHistoryModal
    const handleViewProfileHistory = async (profileId: string) => {
        try {
            const data = await orchestratorService.getProfileHistory(profileId);
            setProfileHistoryData(
                data.items.map((s: any) => ({
                    id:        s.id.toString(),
                    type:      s.status === 'closed'  ? 'SUCCESS'
                             : s.status === 'crashed' ? 'ERROR'
                             : 'INFO',
                    message:   `${s.agent_name} — ${s.target_url ?? 'N/A'} (${s.duration_seconds ?? 0}s, ${(s.total_data_mb ?? 0).toFixed(1)} MB)`,
                    source:    `Computer #${s.computer_id}`,
                    timestamp: s.requested_at,
                }))
            );
            setSelectedProfileHistoryId(profileId);
        } catch {
            alert('No se pudo cargar el historial del perfil.');
        }
    };

    const handleAlertAck = async (id: number) => {
        await orchestratorService.ackAlert(id);
        setAlerts(prev => prev.map(a => a.id === id ? { ...a, read: true } : a));
    };

    const handleAlertSilence = async (id: number) => {
        await orchestratorService.silenceAlert(id, 30);
        setAlerts(prev => prev.map(a => a.id === id ? { ...a, read: true } : a));
        alert('Alerta silenciada por 30 minutos');
    };

    const handleTriggerBackup = async () => {
        try {
            await orchestratorService.triggerBackup();
            alert('Backup encolado correctamente');
        } catch {
            alert('Error al iniciar backup');
        }
    };

    const handleRotateProxies = async () => {
        if (!window.confirm('¿Rotar todos los proxies lentos ahora?')) return;
        try {
            await orchestratorService.rotateAllProxies();
            alert('Rotación iniciada en background');
        } catch {
            alert('Error al iniciar rotación de proxies');
        }
    };

    // ─── FILTERED CONTENT ─────────────────────────────────────────
    const visibleContent = useMemo(() => {
        const q = searchText.toLowerCase();
        if (activeTab === 'NODES')
            return nodes.filter(n => n.name.toLowerCase().includes(q));

        if (activeTab === 'PROFILES') {
            return profiles.filter(p => {
                const nameMatch   = p.name.toLowerCase().includes(q) || (p.owner ?? '').toLowerCase().includes(q);
                const ownerMatch  = dashFilters.owner === 'ALL' || p.owner === dashFilters.owner;
                const cookieMatch = dashFilters.cookieStatus === 'ALL' || p.cookieStatus === dashFilters.cookieStatus;
                return nameMatch && ownerMatch && cookieMatch;
            });
        }

        if (activeTab === 'ALERTS')
            return alerts.filter(a => a.message.toLowerCase().includes(q));

        if (activeTab === 'CONNECTIONS')
            return connections.filter(c => c.url.toLowerCase().includes(q));

        return [];
    }, [activeTab, nodes, profiles, alerts, connections, searchText, dashFilters]);

    // ─── RENDER ───────────────────────────────────────────────────
    return (
        <div className="w-full h-full bg-[#020202] text-[#f0f0f0] flex overflow-hidden font-sans selection:bg-[#00ff88]/30">

            {/* SIDEBAR */}
            <aside className="w-20 bg-[#050505] border-r border-white/5 flex flex-col items-center py-6 gap-8 shrink-0 z-50 shadow-[4px_0_20px_rgba(0,0,0,0.5)]">
                <div
                    onClick={() => navigate('/ops/operator')}
                    className="size-12 bg-white/5 text-[#666] hover:bg-white/10 hover:text-white rounded-2xl flex items-center justify-center cursor-pointer transition-colors"
                >
                    <TerminalIcon size={24} />
                </div>

                <nav className="flex flex-col gap-6 w-full px-2">
                    <SidebarItem label="Dash"    active={activeTab === 'DASHBOARD'}   onClick={() => setActiveTab('DASHBOARD')}   icon={<LayoutDashboard size={22} />} />
                    <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                    <SidebarItem label="Nodes"   active={activeTab === 'NODES'}       onClick={() => setActiveTab('NODES')}       icon={<Monitor size={22} />} />
                    <SidebarItem label="Net"     active={activeTab === 'CONNECTIONS'} onClick={() => setActiveTab('CONNECTIONS')} icon={<Globe size={22} />} />
                    <SidebarItem label="Alerts"  active={activeTab === 'ALERTS'}      onClick={() => setActiveTab('ALERTS')}      icon={<Bell size={22} />} />
                    <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />
                    <SidebarItem label="Profs"   active={activeTab === 'PROFILES'}    onClick={() => setActiveTab('PROFILES')}    icon={<Users size={22} />} />
                </nav>

                <div className="mt-auto">
                    <button
                        onClick={() => setActiveTab('SETTINGS')}
                        className={`size-10 rounded-xl flex items-center justify-center transition-colors ${
                            activeTab === 'SETTINGS'
                                ? 'bg-[#00ff88]/20 text-[#00ff88]'
                                : 'text-[#444] hover:text-white hover:bg-white/5'
                        }`}
                    >
                        <Settings size={20} />
                    </button>
                </div>
            </aside>

            {/* MAIN AREA */}
            <div className="flex-1 flex flex-col overflow-hidden relative bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#00ff8805] via-[#020202] to-[#020202]">

                {/* HEADER */}
                <header className="px-8 py-5 flex justify-between items-center z-40 bg-gradient-to-b from-[#020202] to-transparent">
                    <div className="flex items-center gap-6">
                        <div>
                            <h1 className="text-2xl font-black tracking-tighter flex items-center gap-3 italic">
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00ff88] to-[#00b560]">WB</span>
                                <span className="text-white drop-shadow-[0_2px_10px_rgba(0,0,0,0.5)]">ORCHESTRATOR</span>
                            </h1>
                            <p className="text-[10px] font-bold text-[#666] uppercase tracking-[0.3em] ml-1">Infraestructura & Agentes</p>
                        </div>
                        <div className="h-8 w-px bg-white/10 mx-2" />
                        <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-xl border border-white/5 backdrop-blur-md">
                            <ServiceStatusBar services={services} onServiceClick={setSelectedService} />
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="relative group hidden md:block">
                            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#444] group-focus-within:text-[#00ff88] transition-colors" />
                            <input
                                type="text"
                                placeholder="Buscar nodo / perfil / error..."
                                value={searchText}
                                onChange={e => setSearchText(e.target.value)}
                                className="bg-[#0a0a0a] border border-white/5 rounded-xl pl-9 pr-4 py-2.5 text-xs font-bold text-white placeholder:text-[#333] focus:border-[#00ff88]/30 focus:outline-none w-64 transition-all focus:w-80"
                            />
                        </div>
                        <button
                            onClick={fetchData}
                            disabled={refreshing}
                            className={`p-3 rounded-xl border border-white/5 bg-white/5 text-[#888] hover:text-white hover:bg-white/10 transition-all ${refreshing ? 'animate-spin cursor-not-allowed' : ''}`}
                        >
                            <RefreshCw size={18} />
                        </button>
                        <button
                            onClick={() => navigate('/ops/operator')}
                            className="flex items-center gap-2 px-6 py-3 bg-[#0a0a0a] border border-white/10 text-white text-[11px] font-black uppercase rounded-xl hover:bg-white/5 transition-all"
                        >
                            <ExternalLink size={16} /> Ir a Operador
                        </button>
                    </div>
                </header>

                {/* CONTENT */}
                <main className="flex-1 overflow-y-auto custom-scrollbar p-8 pt-2 pb-40 scroll-smooth">
                    <div className="max-w-[1600px] mx-auto space-y-12 animate-fade-in pb-20">

                        {/* ── DASHBOARD ─────────────────────────────────── */}
                        {activeTab === 'DASHBOARD' && (
                            <div className="space-y-8 animate-in fade-in">
                                <div className="flex justify-between items-end">
                                    <div>
                                        <h2 className="text-xl font-black text-white italic tracking-tight">Panel de Control</h2>
                                        <p className="text-xs text-[#666]">Vista general del estado de la infraestructura.</p>
                                    </div>
                                    <button
                                        onClick={() => setShowDashFilters(true)}
                                        className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/5 rounded-lg text-xs font-bold text-[#ccc] hover:text-white hover:bg-white/10 transition-colors"
                                    >
                                        <Filter size={14} /> Filtros
                                        {dashFilters.severity !== 'ALL' && <span className="size-1.5 rounded-full bg-[#00ff88]" />}
                                    </button>
                                </div>

                                {/* HERO ROW */}
                                <section className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                                    <div className="lg:col-span-2">
                                        <GlobalStatusHero
                                            status={(stats?.healthScore || 0) > 80 ? 'OK' : 'DEGRADED'}
                                            lastUpdate="2s"
                                            autoRefresh={autoRefresh}
                                            onToggleAuto={() => setAutoRefresh(v => !v)}
                                            onClick={() => setShowSystemDiag(true)}
                                        />
                                    </div>
                                    <div className="lg:col-span-1 h-full">
                                        <MiniCapacityPanel
                                            cpu={Math.round(nodes.reduce((a, b) => a + b.cpu, 0) / (nodes.length || 1))}
                                            ram={Math.round(nodes.reduce((a, b) => a + b.ram, 0) / (nodes.length || 1))}
                                            net={45}
                                            onClick={() => setShowResourceDetail(true)}
                                        />
                                    </div>
                                    <div className="lg:col-span-1 h-full">
                                        {/* JobsQueueWidget sin jobs reales — solo muestra KPIs de sesiones */}
                                        <JobsQueueWidget
                                            queue={0}
                                            running={stats?.browsersOpen ?? 0}
                                            failed={alerts.filter(a => !a.read).length}
                                            onClick={() => setShowJobQueue(true)}
                                        />
                                    </div>
                                </section>

                                {/* KPI CARDS */}
                                <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                    <AdminKPICard
                                        label="Computadoras Online"
                                        value={stats ? `${stats.nodesOnline}/${stats.nodesTotal}` : '-/-'}
                                        icon={<Server size={20} />}
                                        active
                                        loading={loading}
                                        trend="+2 vs 1h"
                                        tooltip="Nodos conectados y respondiendo"
                                        onClick={() => setDashModal({ type: 'NODES', data: nodes })}
                                    />
                                    <AdminKPICard
                                        label="Perfiles Activos"
                                        value={stats ? stats.profilesActive.toString() : '-'}
                                        icon={<Users size={20} />}
                                        loading={loading}
                                        trend="Stable"
                                        tooltip="Sesiones de usuario actualmente activas"
                                        onClick={() => setDashModal({ type: 'PROFILES', data: profiles.filter(p => p.status !== 'IDLE') })}
                                    />
                                    <AdminKPICard
                                        label="Navegadores Abiertos"
                                        value={stats ? stats.browsersOpen.toString() : '-'}
                                        icon={<CheckCircle2 size={20} />}
                                        loading={loading}
                                        tooltip="Instancias de Chrome ejecutándose"
                                        onClick={() => setDashModal({ type: 'BROWSERS', data: nodes.map(n => ({ name: n.name, openBrowsers: n.openBrowsers })) })}
                                    />
                                    <AdminKPICard
                                        label="Alertas Activas"
                                        value={stats ? stats.alertsActive.toString() : '-'}
                                        icon={<AlertTriangle size={20} />}
                                        alert={(stats?.alertsActive || 0) > 0}
                                        loading={loading}
                                        trend={stats?.alertsActive ? '+1 Reciente' : '0'}
                                        tooltip="Alertas que requieren atención inmediata"
                                        onClick={() => setDashModal({ type: 'ALERTS', data: alerts.filter(a => !a.read) })}
                                    />
                                </section>

                                {/* HEALTH + EVENTS */}
                                <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[400px]">
                                    <div className="lg:col-span-1">
                                        <HealthOverview
                                            score={stats?.healthScore || 0}
                                            risks={stats?.healthRisks || []}
                                            onDetails={() => setShowHealthDetail(true)}
                                        />
                                    </div>
                                    <div className="lg:col-span-2">
                                        <SystemEventsFeed
                                            events={events}
                                            onEventClick={ev => setSelectedEvent(ev)}
                                        />
                                    </div>
                                </section>

                                {/* AGENT ACTION PANEL */}
                                <section className="bg-[#0c0c0c] border border-white/5 rounded-2xl p-6">
                                    <h3 className="text-[10px] font-black text-[#444] uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                                        <TerminalIcon size={12} className="text-[#00ff88]" /> Panel de Agente
                                    </h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

                                        {/* Iniciar Sesión */}
                                        <div
                                            onClick={() => setShowSessionModal(true)}
                                            className="group cursor-pointer bg-[#0a0a0a] border border-white/5 hover:border-[#00ff88]/50 p-4 rounded-xl transition-all relative overflow-hidden"
                                        >
                                            <div className="absolute inset-0 bg-[#00ff88]/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                                            <div className="relative z-10 flex items-center gap-4">
                                                <div className="bg-[#00ff88]/10 text-[#00ff88] p-3 rounded-lg group-hover:scale-110 transition-transform">
                                                    <Monitor size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-white uppercase text-sm">Iniciar Sesión</h4>
                                                    <p className="text-[10px] text-[#666] mt-1">Seleccionar y abrir perfiles</p>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Nuevo Perfil */}
                                        <div
                                            onClick={() => setShowCreateProfileModal(true)}
                                            className="group cursor-pointer bg-[#0a0a0a] border border-white/5 hover:border-white/30 p-4 rounded-xl transition-all relative overflow-hidden"
                                        >
                                            <div className="absolute inset-0 bg-white/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                                            <div className="relative z-10 flex items-center gap-4">
                                                <div className="bg-white/10 text-white p-3 rounded-lg group-hover:scale-110 transition-transform">
                                                    <Plus size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-white uppercase text-sm">Nuevo Perfil</h4>
                                                    <p className="text-[10px] text-[#666] mt-1">Crear navegador y credenciales</p>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Monitor de Red / Rotar Proxies */}
                                        <div
                                            onClick={handleRotateProxies}
                                            className="group cursor-pointer bg-[#0a0a0a] border border-white/5 hover:border-blue-500/50 p-4 rounded-xl transition-all relative overflow-hidden"
                                        >
                                            <div className="absolute inset-0 bg-blue-500/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                                            <div className="relative z-10 flex items-center gap-4">
                                                <div className="bg-blue-500/10 text-blue-500 p-3 rounded-lg group-hover:scale-110 transition-transform">
                                                    <RefreshCw size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-white uppercase text-sm">Monitor de Red</h4>
                                                    <p className="text-[10px] text-[#666] mt-1">Rotar proxies lentos ahora</p>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Logs de Sistema */}
                                        <div
                                            onClick={() => setActiveTab('ALERTS')}
                                            className="group cursor-pointer bg-[#0a0a0a] border border-white/5 hover:border-amber-500/50 p-4 rounded-xl transition-all relative overflow-hidden"
                                        >
                                            <div className="absolute inset-0 bg-amber-500/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                                            <div className="relative z-10 flex items-center gap-4">
                                                <div className="bg-amber-500/10 text-amber-500 p-3 rounded-lg group-hover:scale-110 transition-transform">
                                                    <History size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-white uppercase text-sm">Logs de Sistema</h4>
                                                    <p className="text-[10px] text-[#666] mt-1">Ver alertas y eventos</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        )}

                        {/* ── LIST VIEWS ────────────────────────────────── */}
                        {activeTab !== 'DASHBOARD' && activeTab !== 'SETTINGS' && (
                            <section className="space-y-6 animate-in slide-in-from-bottom-4">
                                {/* Sticky toolbar */}
                                <div className="sticky top-0 z-30 flex items-center justify-between p-2 bg-[#0c0c0c]/80 backdrop-blur-xl border border-white/5 rounded-2xl shadow-xl">
                                    <div className="flex items-center gap-4 pl-4">
                                        <h3 className="text-[12px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                                            {activeTab === 'NODES'       && <Monitor size={14} className="text-[#00ff88]" />}
                                            {activeTab === 'CONNECTIONS' && <Globe   size={14} className="text-[#00ff88]" />}
                                            {activeTab === 'ALERTS'      && <Bell    size={14} className="text-[#00ff88]" />}
                                            {activeTab === 'PROFILES'    && <Users   size={14} className="text-[#00ff88]" />}
                                            {activeTab} VIEW
                                        </h3>
                                        <div className="h-4 w-px bg-white/10" />
                                        <div className="flex gap-1">
                                            <FilterButton label="Computadoras" active={activeTab === 'NODES'}       onClick={() => setActiveTab('NODES')} />
                                            <FilterButton label="Conexiones"   active={activeTab === 'CONNECTIONS'} onClick={() => setActiveTab('CONNECTIONS')} />
                                            <FilterButton
                                                label="Alertas"
                                                active={activeTab === 'ALERTS'}
                                                onClick={() => setActiveTab('ALERTS')}
                                                dotColor={(stats?.alertsActive || 0) > 0 ? 'bg-red-500' : ''}
                                            />
                                        </div>
                                        <div className="relative group">
                                            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#444] group-focus-within:text-[#00ff88] transition-colors" />
                                            <input
                                                type="text"
                                                placeholder="Buscar item..."
                                                value={searchText}
                                                onChange={e => setSearchText(e.target.value)}
                                                className="bg-black/40 border border-white/5 rounded-xl pl-9 pr-4 py-2 text-xs font-bold text-white placeholder:text-[#333] focus:border-[#00ff88]/30 focus:outline-none w-48 transition-all focus:w-64"
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* List content */}
                                <div className="space-y-4 min-h-[400px]">
                                    {loading ? (
                                        <><SkeletonRow /><SkeletonRow /></>
                                    ) : (
                                        <>
                                            {activeTab === 'NODES' && visibleContent.map((node: any) => (
                                                <ComputerRow key={node.id} node={node} onClick={() => handleNodeClick(node)} />
                                            ))}

                                            {activeTab === 'CONNECTIONS' && visibleContent.map((conn: any) => (
                                                <ConnectionRow key={conn.id} conn={conn} />
                                            ))}

                                            {activeTab === 'PROFILES' && (
                                                <div className="bg-[#0a0a0a] border border-white/5 rounded-2xl overflow-hidden">
                                                    <div className="grid grid-cols-12 gap-2 md:gap-4 p-3 border-b border-white/5 bg-white/[0.01] text-[9px] font-black text-[#666] uppercase tracking-wider pl-4">
                                                        <div className="col-span-4 md:col-span-3">Perfil</div>
                                                        <div className="col-span-2 hidden md:block">Proxy Speed</div>
                                                        <div className="col-span-2 hidden md:block">Cookies</div>
                                                        <div className="col-span-3 md:col-span-2">Nodo</div>
                                                        <div className="col-span-3 md:col-span-2 text-right pr-4">Acciones</div>
                                                    </div>
                                                    {/* ✅ FIX 9: ProfileRow dentro del return, no flotando */}
                                                    {(visibleContent as ProfileItem[]).map(profile => (
                                                        <ProfileRow
                                                            key={profile.id}
                                                            profile={profile}
                                                            onHistory={() => handleViewProfileHistory(profile.id)}
                                                            onSecurity={() => setSecurityProfile(profile)}
                                                        />
                                                    ))}
                                                </div>
                                            )}

                                            {activeTab === 'ALERTS' && visibleContent.map((alert: any) => (
                                                <AlertItem
                                                    key={alert.id}
                                                    alert={alert}
                                                    onRead={() => setSelectedAlert(alert)}
                                                    onAction={(action: string) => {
                                                        if (action === 'SILENCE') handleAlertSilence(alert.id);
                                                        if (action === 'RETRY')      alert.message && fetchData();
                                                        if (action === 'VIEW_CAUSE') setSelectedAlert(alert);
                                                    }}
                                                />
                                            ))}

                                            {visibleContent.length === 0 && (
                                                <div className="p-12 text-center border border-dashed border-white/5 rounded-2xl">
                                                    <p className="text-[#444] text-xs font-bold uppercase">No data found</p>
                                                </div>
                                            )}
                                        </>
                                    )}
                                </div>
                            </section>
                        )}

                        {/* ── SETTINGS ──────────────────────────────────── */}
                        {activeTab === 'SETTINGS' && (
                            <div className="animate-in fade-in">
                                <SettingsPanel
                                    backupStatus={backupStatus}
                                    onTriggerBackup={handleTriggerBackup}
                                />
                            </div>
                        )}
                    </div>
                </main>

                {/* ─── MODALS & DRAWERS ──────────────────────────────── */}

                <EventDetailModal
                    event={selectedEvent}
                    onClose={() => setSelectedEvent(null)}
                />

                <SystemDiagnosticModal
                    isOpen={showSystemDiag}
                    onClose={() => setShowSystemDiag(false)}
                />

                <ResourceDetailModal
                    isOpen={showResourceDetail}
                    onClose={() => setShowResourceDetail(false)}
                />

                <JobQueueModal
                    isOpen={showJobQueue}
                    onClose={() => setShowJobQueue(false)}
                />

                <NodeItemDrawer
                    node={selectedNode}
                    history={nodeHistory}
                    onClose={() => setSelectedNode(null)}
                />

                <AlertModal
                    alert={selectedAlert}
                    onClose={() => setSelectedAlert(null)}
                    onAck={handleAlertAck}
                />

                <DashFiltersDrawer
                    isOpen={showDashFilters}
                    onClose={() => setShowDashFilters(false)}
                    filters={dashFilters}
                    setFilters={setDashFilters}
                    onReset={() => setDashFilters({ timeRange: '1h', severity: 'ALL', owner: 'ALL', cookieStatus: 'ALL' })}
                />

                <DashKPIModal
                    type={dashModal.type}
                    data={dashModal.data}
                    onClose={() => setDashModal({ type: null, data: null })}
                />

                <HealthDetailModal
                    isOpen={showHealthDetail}
                    score={stats?.healthScore || 0}
                    onClose={() => setShowHealthDetail(false)}
                />

                <ServiceDetailModal
                    service={selectedService}
                    onClose={() => setSelectedService(null)}
                />

                {/* ✅ FIX 10: SecurityCheckModal conectado a handleVerifyProfile */}
                <SecurityCheckModal
                    profile={securityProfile}
                    onClose={() => setSecurityProfile(null)}
                    onVerify={(profileId: string) => handleVerifyProfile(profileId)}
                />

                {/* ✅ FIX 11: SessionStartModal conectado a handleStartSessions */}
                <SessionStartModal
                    isOpen={showSessionModal}
                    onClose={() => setShowSessionModal(false)}
                    profiles={profiles}
                    onStart={handleStartSessions}
                />

                {/* ✅ FIX 12: SessionHistoryModal ahora se renderiza */}
                <SessionHistoryModal
                    isOpen={selectedProfileHistoryId !== null}
                    events={profileHistoryData}
                    profileId={selectedProfileHistoryId}
                    onClose={() => {
                        setSelectedProfileHistoryId(null);
                        setProfileHistoryData([]);
                    }}
                />

                <CreateProfileModal
                    isOpen={showCreateProfileModal}
                    onClose={() => setShowCreateProfileModal(false)}
                    onCreate={async (data: any) => {
                        try {
                            await orchestratorService.createProfile(data);
                            alert(`Perfil "${data.name}" creado correctamente.`);
                            setShowCreateProfileModal(false);
                            fetchData();
                        } catch {
                            alert('Error al crear el perfil. Revisa la conexión con AdsPower.');
                        }
                    }}
                />
            </div>
        </div>
    );
};

export default OrchestratorTerminal;