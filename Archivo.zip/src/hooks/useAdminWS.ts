import { useEffect, useCallback } from 'react';

type WSEvent = {
  type: 'session_created' | 'session_active' | 'session_closed' |
        'agent_checkin'   | 'browser_event'  | 'session_denied';
  [key: string]: any;
};

export function useAdminWS(
  onEvent: (e: WSEvent) => void,
  enabled  = true
) {
  const connect = useCallback(() => {
    if (!enabled) return;

    const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${protocol}://${window.location.hostname}:8000/api/v1/admin/ws`);

    ws.onopen = () => console.log('[WS] Admin conectado');

    ws.onmessage = (msg) => {
      try {
        const data = JSON.parse(msg.data);
        if (data.type !== 'pong') onEvent(data);
      } catch {}
    };

    ws.onclose = () => {
      // Reconexión automática en 3s
      setTimeout(connect, 3000);
    };

    const ping = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN)
        ws.send(JSON.stringify({ type: 'ping' }));
    }, 25000);

    return () => { clearInterval(ping); ws.close(); };
  }, [enabled, onEvent]);

  useEffect(() => {
    const cleanup = connect();
    return cleanup;
  }, [connect]);
}